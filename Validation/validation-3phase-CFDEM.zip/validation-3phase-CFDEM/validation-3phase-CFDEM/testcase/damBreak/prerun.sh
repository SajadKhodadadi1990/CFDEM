#!/bin/bash

pushd CFD

cp -r 0.org 0
setFields

popd

